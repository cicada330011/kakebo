const KEY='kakebo_db_v1';
const LEGACY_KEY='finora_modular_db_v1';
export const defaultDB=()=>({version:1,currency:'BDT',symbol:'৳',theme:'dark',walletTypes:['Cash','MFS','Credit','Debit','Bank','Other'],wallets:[{id:'w_cash',name:'Cash',type:'Cash',balance:0},{id:'w_bkash',name:'bKash',type:'MFS',balance:0},{id:'w_nagad',name:'Nagad',type:'MFS',balance:0},{id:'w_bank',name:'Bank',type:'Bank',balance:0}],expenseCategories:['Food','Transport','Shopping','Bills','Health','Education','Entertainment','Other'].map((name,i)=>({id:'ec'+i,name,type:'expense'})),incomeSources:['Salary','Freelance','Business','Gift / Family Help','Other'].map((name,i)=>({id:'ic'+i,name,type:'income'})),transactions:[],transfers:[],debts:[],savingsMovements:[],settings:{defaultWalletId:'w_cash'}});
let state;
export function loadDB(){try{const raw=localStorage.getItem(KEY) || localStorage.getItem(LEGACY_KEY);const saved=raw?JSON.parse(raw):null;state={...defaultDB(),...(saved||{})};for(const k of ['wallets','expenseCategories','incomeSources','transactions','transfers','debts','savingsMovements'])if(!Array.isArray(state[k]))state[k]=[];if(!Array.isArray(state.savingsLoans))state.savingsLoans=[];if(!Array.isArray(state.regularLoans))state.regularLoans=[];return state}catch{return state=defaultDB()}}
export function getDB(){return state||loadDB()}
export function saveDB(){localStorage.setItem(KEY,JSON.stringify(getDB()));window.dispatchEvent(new CustomEvent('finora:changed'));}
export function makeId(prefix='id'){return prefix+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
export function money(n){const db=getDB();return `${db.symbol||'৳'}${Number(n||0).toLocaleString('en-BD',{maximumFractionDigits:2})}`}
export function walletById(id){return getDB().wallets.find(w=>w.id===id)}
export function categoryList(type){return type==='income'?getDB().incomeSources:getDB().expenseCategories}
export function addCategory(name,type){const list=categoryList(type),clean=name.trim();if(!clean)throw Error('Enter a name');if(list.some(x=>x.name.toLowerCase()===clean.toLowerCase()))throw Error('This option already exists');const item={id:makeId(type==='income'?'inc':'exp'),name:clean,type};list.push(item);saveDB();return item}
export function addWalletType(name){const clean=name.trim();if(!clean)throw Error('Enter a type name');const types=getDB().walletTypes||(getDB().walletTypes=['Cash','MFS','Credit','Debit','Bank','Other']);if(types.some(x=>x.toLowerCase()===clean.toLowerCase()))throw Error('Wallet type already exists');types.push(clean);saveDB();return clean}
export function addWallet(name,type,opening=0){const clean=name.trim();if(!clean)throw Error('Enter a wallet name');if(getDB().wallets.some(x=>x.name.toLowerCase()===clean.toLowerCase()))throw Error('Wallet already exists');const w={id:makeId('wallet'),name:clean,type,balance:Number(opening)||0};getDB().wallets.push(w);saveDB();return w}

export function getSavingsWallet(create=true){const db=getDB();let w=db.wallets.find(x=>x.isSavings);if(!w&&create){w={id:'wallet_savings',name:'Savings Account',type:'Bank',balance:0,isSavings:true,active:true};db.wallets.push(w);saveDB();}return w||null;}
export function currentWalletTotal(){return getDB().wallets.filter(w=>!w.isSavings&&w.active!==false).reduce((s,w)=>s+Number(w.balance||0),0)}
