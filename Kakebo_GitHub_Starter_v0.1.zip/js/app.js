import {loadDB} from './db.js';
import {initUI} from './ui.js';
loadDB();initUI();
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
