// Public interface for the future cloud adapter. Local persistence remains the source of truth
// until Google OAuth configuration and an end-to-end backup/restore test are complete.
export async function getBackupStatus(){return {connected:false,provider:'Google Drive / Sheets',message:'OAuth setup pending'};}
export async function connectGoogle(){throw new Error('Google OAuth is not configured yet.');}
export async function backupNow(){throw new Error('Google online backup is not active yet.');}
export async function restoreFromGoogle(){throw new Error('Google online restore is not active yet.');}
