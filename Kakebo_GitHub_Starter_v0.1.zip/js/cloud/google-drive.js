// Google Identity Services + Sheets API adapter will be implemented after GitHub Pages URL
// and OAuth Web Client ID are available. Do not place private client secrets in this file.
export const GOOGLE_CONFIG={clientId:'',spreadsheetId:'',scopes:['https://www.googleapis.com/auth/spreadsheets']};
export function isGoogleConfigured(){return Boolean(GOOGLE_CONFIG.clientId&&GOOGLE_CONFIG.spreadsheetId);}
