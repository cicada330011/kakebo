import {getDB,money,categoryList,walletById} from '../db.js';
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const pageHead=(t,sub,action='')=>`<div class="page-head"><div><h1>${t}</h1><p>${sub}</p></div>${action}</div>`;
export const field=(label,html)=>`<div class="field"><label>${label}</label>${html}</div>`;
export function walletSelect(name='walletId',includeSavings=false){return `<div class="select-add"><select name="${name}" required><option value="">Select wallet</option>${getDB().wallets.filter(w=>(includeSavings||!w.isSavings)&&w.active!==false).map(w=>`<option value="${w.id}">${esc(w.name)} · ${money(w.balance)}</option>`).join('')}</select><button type="button" class="add-option" data-add="wallet" data-target="${name}" title="Add wallet">＋</button></div>`}
export function categorySelect(type,name='categoryId'){return `<div class="select-add"><select name="${name}" required><option value="">Select ${type==='income'?'source':'category'}</option>${categoryList(type).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button type="button" class="add-option" data-add="${type}" data-target="${name}" title="Add ${type==='income'?'source':'category'}">＋</button></div>`}
export {getDB,money,walletById};
