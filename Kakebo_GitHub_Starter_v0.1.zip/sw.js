const CACHE='finora-shell-v1-1';
const FILES=['./','./index.html','./css/main.css','./manifest.webmanifest','./js/app.js','./js/db.js','./js/ledger.js','./js/ui.js','./js/backup-sync.js','./js/cloud/google-drive.js','./js/pages/common.js','./js/pages/dashboard.js','./js/pages/transactions.js','./js/pages/wallets.js','./js/pages/transfer.js','./js/pages/debts.js','./js/pages/savings.js','./js/pages/categories.js','./js/pages/settings.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES))));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return res}).catch(()=>caches.match('./index.html'))))});
