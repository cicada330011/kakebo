# Kakebo Changelog

## 0.1.0 - Initial GitHub baseline
- Rebranded the app shell as Kakebo.
- Added a modern dark UI refinement with restrained hover/press motion and reduced-motion support.
- Separated Savings-funded loans from regular-wallet loans in data storage and repayment routing.
- Added Savings value breakdown: available savings, Savings loans receivable, and total Savings value.
- Preserved regular wallet balances as separate from Savings.

## Not yet complete
- Google OAuth and automatic Google Drive/Sheets backup.
- Full automated test suite and end-to-end verification.
- Remaining screens and workflows still need iterative implementation and testing.
