# Kakebo Expense Tracker — Modular v1

A static vanilla-JavaScript application designed for GitHub Pages and Android WebView wrappers such as WebIntoApp.

## Project structure

- `index.html` — app shell, dialogs, navigation
- `css/main.css` — shared design system and responsive styling
- `js/app.js` — bootstrap
- `js/db.js` — local database, defaults, wallets, categories, localStorage
- `js/ledger.js` — transaction, transfer and debt/loan accounting rules
- `js/ui.js` — navigation, forms, events, import/export
- `js/pages/` — one module per menu: dashboard, transactions, wallets, transfer, debts, categories, settings
- `js/pages/common.js` — shared UI helpers and dropdown builders
- `js/backup-sync.js` — cloud backup interface
- `js/cloud/google-drive.js` — Google OAuth/Sheets adapter configuration placeholder
- `manifest.webmanifest`, `sw.js` — PWA metadata and offline shell

## Run locally

Serve over HTTP (ES modules do not work reliably from `file://`):

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish to GitHub Pages

Upload the contents of this folder to the repository root, then enable Pages from `main` / root. The app uses relative paths and ES modules.

## Implemented in this baseline

- Default wallets: Cash, bKash, Nagad, Bank
- Custom wallets and wallet types
- Income and expense transactions
- Inline `+` add controls beside wallet and category/source dropdowns; new option is added and selected in the active form
- Duplicate name checks for wallets and categories
- Wallet-to-wallet transfers update source and target balances without creating income/expense entries
- Debt/Loan: money lent reduces wallet balance; money borrowed increases wallet balance; repayments support partial and full settlement and do not create income/expense entries
- Local JSON export/import
- localStorage persistence

## Cloud backup status

Google online backup is **not active yet**. The app intentionally shows it as pending. After GitHub Pages is published, configure the OAuth Web Client ID and spreadsheet ID in `js/cloud/google-drive.js`, then implement and test the Google Sheets backup/restore adapter. Do not treat a Google account as connected until a real backup and restore test succeeds.

## Notes

This is the first functional modular baseline, not the final visual match to the reference video. Re-check visual layout against the source video before final release. Do not put OAuth client secrets or service-account private keys in frontend code.


## Savings module (added)
- Dedicated Savings Account is excluded from Dashboard Total Current Balance and ordinary Wallet overview.
- Save Money moves funds from a regular wallet into Savings as an internal transfer (not income).
- Withdraw moves funds from Savings to a regular wallet and creates a pending-return record.
- Return can be partial or full; returned funds move back to Savings.
- Mark Expense finalizes the unreturned remainder as an expense and deducts it from the receiving wallet.
- Lending directly from the Savings wallet is supported in Debt / Loan; repayments return to that same wallet.


## Savings rules in this build
1. The Savings account is a separate, dedicated Bank-type wallet.
2. Savings balance is hidden from the Dashboard and excluded from Total Current Balance.
3. Saving money transfers from a regular wallet into Savings; it is not income.
4. Withdrawing from Savings moves money to a regular wallet and creates a Pending Return.
5. A pending withdrawal can be returned partially or fully. Returned money moves back to Savings.
6. Any remaining pending amount can be finalized as an Expense. Finalizing deducts it from the receiving wallet and records an Expense.
7. Debt / Loan can use the Savings wallet as the source for money lent; repayment returns to that same wallet.

## Upload
Upload the contents of this folder to the root of your GitHub Pages repository. Keep the folder structure unchanged. Open `index.html` through the published HTTPS GitHub Pages URL. The app stores data in that browser's local storage; export a JSON backup regularly until Google cloud sync is configured.


## Development status
This is the initial Kakebo source baseline. It includes the modular web-app shell and an initial separation between Savings-funded loans and regular-wallet loans. Google OAuth/online backup is not configured yet; do not treat local JSON export as Google backup.
